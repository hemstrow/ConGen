#!/bin/bash

~/Desktop/Applications/Structure/command_line/structure -K 1 -o /home/jared/Desktop/ICCB_Workshop/Structure/Results/k1_run_1 -D 1356091
~/Desktop/Applications/Structure/command_line/structure -K 1 -o /home/jared/Desktop/ICCB_Workshop/Structure/Results/k1_run_2 -D 60145
~/Desktop/Applications/Structure/command_line/structure -K 1 -o /home/jared/Desktop/ICCB_Workshop/Structure/Results/k1_run_3 -D 460
~/Desktop/Applications/Structure/command_line/structure -K 1 -o /home/jared/Desktop/ICCB_Workshop/Structure/Results/k1_run_4 -D 6024
~/Desktop/Applications/Structure/command_line/structure -K 1 -o /home/jared/Desktop/ICCB_Workshop/Structure/Results/k1_run_5 -D 982746

~/Desktop/Applications/Structure/command_line/structure -K 2 -o /home/jared/Desktop/ICCB_Workshop/Structure/Results/k2_run_1 -D 872
~/Desktop/Applications/Structure/command_line/structure -K 2 -o /home/jared/Desktop/ICCB_Workshop/Structure/Results/k2_run_2 -D 2
~/Desktop/Applications/Structure/command_line/structure -K 2 -o /home/jared/Desktop/ICCB_Workshop/Structure/Results/k2_run_3 -D 3
~/Desktop/Applications/Structure/command_line/structure -K 2 -o /home/jared/Desktop/ICCB_Workshop/Structure/Results/k2_run_4 -D 4
~/Desktop/Applications/Structure/command_line/structure -K 2 -o /home/jared/Desktop/ICCB_Workshop/Structure/Results/k2_run_5 -D 5

~/Desktop/Applications/Structure/command_line/structure -K 3 -o /home/jared/Desktop/ICCB_Workshop/Structure/Results/k3_run_1 -D 6
~/Desktop/Applications/Structure/command_line/structure -K 3 -o /home/jared/Desktop/ICCB_Workshop/Structure/Results/k3_run_2 -D 7
~/Desktop/Applications/Structure/command_line/structure -K 3 -o /home/jared/Desktop/ICCB_Workshop/Structure/Results/k3_run_3 -D 8
~/Desktop/Applications/Structure/command_line/structure -K 3 -o /home/jared/Desktop/ICCB_Workshop/Structure/Results/k3_run_4 -D 9
~/Desktop/Applications/Structure/command_line/structure -K 3 -o /home/jared/Desktop/ICCB_Workshop/Structure/Results/k3_run_5 -D 10

~/Desktop/Applications/Structure/command_line/structure -K 4 -o /home/jared/Desktop/ICCB_Workshop/Structure/Results/k4_run_1 -D 11
~/Desktop/Applications/Structure/command_line/structure -K 4 -o /home/jared/Desktop/ICCB_Workshop/Structure/Results/k4_run_2 -D 12
~/Desktop/Applications/Structure/command_line/structure -K 4 -o /home/jared/Desktop/ICCB_Workshop/Structure/Results/k4_run_3 -D 13
~/Desktop/Applications/Structure/command_line/structure -K 4 -o /home/jared/Desktop/ICCB_Workshop/Structure/Results/k4_run_4 -D 14
~/Desktop/Applications/Structure/command_line/structure -K 4 -o /home/jared/Desktop/ICCB_Workshop/Structure/Results/k4_run_5 -D 15

~/Desktop/Applications/Structure/command_line/structure -K 5 -o /home/jared/Desktop/ICCB_Workshop/Structure/Results/k5_run_1 -D 16
~/Desktop/Applications/Structure/command_line/structure -K 5 -o /home/jared/Desktop/ICCB_Workshop/Structure/Results/k5_run_2 -D 17
~/Desktop/Applications/Structure/command_line/structure -K 5 -o /home/jared/Desktop/ICCB_Workshop/Structure/Results/k5_run_3 -D 18
~/Desktop/Applications/Structure/command_line/structure -K 5 -o /home/jared/Desktop/ICCB_Workshop/Structure/Results/k5_run_4 -D 19
~/Desktop/Applications/Structure/command_line/structure -K 5 -o /home/jared/Desktop/ICCB_Workshop/Structure/Results/k5_run_5 -D 20